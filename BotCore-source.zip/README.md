# BotCore

BotCore is a lightweight Fabric utility mod project for Minecraft Java 26.3. This first development build establishes the command framework before the larger features are added.

## Commands in this foundation

- `/bc` or `/bc help` — list commands
- `/bc version` — display BotCore version
- `/bc info` — show a short description
- `/bc coords` — show your current coordinates
- `/bc day` — set daytime (operator permission required)
- `/bc night` — set nighttime (operator permission required)
- `/bc clear` — clear weather (operator permission required)
- `/bc rain` — start rain (operator permission required)
- `/bc heal` — apply instant health (operator permission required)
- `/bc feed` — restore hunger (operator permission required)

## Build requirements

- JDK 25 or newer
- Gradle wrapper (downloads the configured Gradle version the first time)
- Internet access for Gradle, Fabric Loom, Minecraft, and Fabric API dependencies

Run `./gradlew build` on Linux/macOS or `gradlew.bat build` on Windows. The output JAR should be in `build/libs/` if the build succeeds.

## Important status

This is an initial foundation, not the complete planned BotCore feature set. PvP bots, advanced map-editing tools, kits, and music have not been implemented yet. The project has not been compiled in this environment because the Gradle distribution could not be downloaded and only Java 21 is installed here; the supplied template targets Java 25. Build and test it before using it in a world.
