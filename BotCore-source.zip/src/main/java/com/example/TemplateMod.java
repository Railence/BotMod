package com.example;

import com.mojang.brigadier.CommandDispatcher;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TemplateMod implements ModInitializer {
    public static final String MOD_ID = "botcore";
    public static final String VERSION = "0.1.0-dev";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> registerCommands(dispatcher));
        LOGGER.info("BotCore {} initialized", VERSION);
    }

    private static void registerCommands(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("bc")
            .executes(context -> help(context.getSource()))
            .then(Commands.literal("help").executes(context -> help(context.getSource())))
            .then(Commands.literal("version").executes(context -> {
                context.getSource().sendSuccess(() -> Component.literal("BotCore " + VERSION + " | Minecraft 26.3 | Fabric"), false);
                return 1;
            }))
            .then(Commands.literal("info").executes(context -> {
                CommandSourceStack source = context.getSource();
                source.sendSuccess(() -> Component.literal("BotCore: lightweight QoL tools for map creators and PvP practice."), false);
                source.sendSuccess(() -> Component.literal("Use /bc help to see available commands."), false);
                return 1;
            }))
            .then(Commands.literal("coords").executes(context -> {
                CommandSourceStack source = context.getSource();
                if (!(source.getEntity() instanceof ServerPlayer player)) {
                    source.sendFailure(Component.literal("You must be a player to use this command."));
                    return 0;
                }
                double x = player.getX(), y = player.getY(), z = player.getZ();
                source.sendSuccess(() -> Component.literal(String.format("Position: X %.1f, Y %.1f, Z %.1f", x, y, z)), false);
                return 1;
            }))
            .then(Commands.literal("day").requires(source -> source.hasPermission(2)).executes(context -> runVanilla(context.getSource(), "time set day")))
            .then(Commands.literal("night").requires(source -> source.hasPermission(2)).executes(context -> runVanilla(context.getSource(), "time set night")))
            .then(Commands.literal("clear").requires(source -> source.hasPermission(2)).executes(context -> runVanilla(context.getSource(), "weather clear")))
            .then(Commands.literal("rain").requires(source -> source.hasPermission(2)).executes(context -> runVanilla(context.getSource(), "weather rain")))
            .then(Commands.literal("heal").requires(source -> source.hasPermission(2)).executes(context -> runVanilla(context.getSource(), "effect give @s minecraft:instant_health 1 10 true")))
            .then(Commands.literal("feed").requires(source -> source.hasPermission(2)).executes(context -> runVanilla(context.getSource(), "effect give @s minecraft:saturation 1 10 true")))
        );
    }

    private static int help(CommandSourceStack source) {
        source.sendSuccess(() -> Component.literal("§6§lBotCore §7— commands"), false);
        source.sendSuccess(() -> Component.literal("§e/bc help §7— show this list"), false);
        source.sendSuccess(() -> Component.literal("§e/bc version §7— show version"), false);
        source.sendSuccess(() -> Component.literal("§e/bc info §7— mod information"), false);
        source.sendSuccess(() -> Component.literal("§e/bc coords §7— show your coordinates"), false);
        source.sendSuccess(() -> Component.literal("§e/bc day §7— set daytime (OP)"), false);
        source.sendSuccess(() -> Component.literal("§e/bc night §7— set nighttime (OP)"), false);
        source.sendSuccess(() -> Component.literal("§e/bc clear §7— clear weather (OP)"), false);
        source.sendSuccess(() -> Component.literal("§e/bc rain §7— start rain (OP)"), false);
        source.sendSuccess(() -> Component.literal("§e/bc heal §7— heal yourself (OP)"), false);
        source.sendSuccess(() -> Component.literal("§e/bc feed §7— restore hunger (OP)"), false);
        source.sendSuccess(() -> Component.literal("§7PvP bots, building tools, kits and music are planned for later releases."), false);
        return 1;
    }

    private static int runVanilla(CommandSourceStack source, String command) {
        // Reuse Minecraft's own command implementation so vanilla permission checks and behavior remain intact.
        return source.getServer().getCommands().performPrefixedCommand(source, command);
    }

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }
}
